package edu.exploratorium.rotary;

interface IRotaryInput {
	void dispose ();
}