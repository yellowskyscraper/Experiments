// $Id: README.txt,v 1.1 2009/01/22 04:33:38 webchick Exp $

This directory should be used to place downloaded and custom modules
which are common to all sites. This will allow you to more easily
update Drupal core files.
